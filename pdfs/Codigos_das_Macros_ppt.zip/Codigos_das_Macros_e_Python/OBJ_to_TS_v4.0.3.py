"""
    Wavefront *.obj to GOCAD *.ts file converter.
    Intended to be used with the *.jpg/*.png/*.tif image(s) which
    usually come along with the *.obj file and are used as a
    texture on TSurf in GOCAD (draping using U, V properties)
    
    Some points need to be duplicated, resulting in creating 1 part per "patch"
    Visualization can be highly impacted in SKUA-GOCAD (thousand parts really
    slow down TSurf visualization in SKUA-GOCAD-19). 
    
    Author: mmoriss
    
    script version 4.0.3
    requires Python 3.6 (64bit) at least.
"""
import sys
from glob import glob


# reading filename as first argument from command line
try:
    absolute_obj_filename = sys.argv[1].replace('\\', '/')
except IndexError:
    print("Missing OBJ filename.\nAborting.")
    sys.exit()

path, obj_filename = absolute_obj_filename.rsplit('/', 1)
feature = obj_filename.split(".obj")[0]


LINE_SIZE = 80
LOG = True
verbose = False
ndv = -99999
v = [(ndv, ndv, ndv)]
vt = [(ndv, ndv)]
f = []
g = {}

material = {}
mtllib = {}
mtl_file = None
name = feature
polygon_types = set()
set_colors = False
nb_elements = 0


# a function for logging
def log(*args):
    print(*args)
    if LOG_FILE is not None:
        print(*args, file=LOG_FILE)
        
        
# 2 functions used for fast counting number of lines in file
def _make_gen(reader):
    b = reader(1024 * 1024)
    while b:
        yield b
        b = reader(1024 * 1024)


def rawgencount(filename):
    f = open(filename, 'rb')
    f_gen = _make_gen(f.raw.read)
    return sum(buf.count(b'\n') for buf in f_gen)


# a job tracer to keep progress of processes and display a bar 
class JobTracer:
    def __init__(self, n, limit=LINE_SIZE, top=False):
        self._limit = limit
        self._step = n / self._limit
        self._i = 0
        self._current = 0
        self._perc = 0
        if top:
            print('_' * self._limit, flush=True)
        
    def progress(self):
        self._i += 1
        self._perc = self._i // self._step
        if self._perc > self._current:
            print('#' * int(self._perc - self._current), end='', flush=True)
            self._current = self._perc
            
    def end(self):
        if self._perc < self._limit:
            print('#', end='', flush=True)
        print('', flush=True)
    

######################
# Read geometry file #
######################
try:
    # first try reading OBJ file, therefore we test if it exists and is readable
    nb_lines = rawgencount(f"{path}/{obj_filename}")
except FileNotFoundError:
    print(f"No such file: {path}/{obj_filename}.\nAborting.")
    sys.exit()

# now we can safely create a log file
LOG_FILE = open(f"{path}/{feature}.log", "w") if LOG else None

with open(f"{path}/{obj_filename}", 'r') as file:
    if verbose:
        log(f"Opening '{obj_filename}' file for reading...")
    
    job = JobTracer(nb_lines)
    
    last = None
    for l, line in enumerate(file):
        tokens = line.split()
        
        job.progress()
        
        if not tokens:
            continue
        
        keyword = tokens[0]

        if keyword == 'mtllib':
            mtl_file = tokens[1]
        
        # o = object, g = group
        # each will be a separated TSurf
        elif keyword in ['g', 'o']:
            name = tokens[1]
            g[name] = g.get(name, [])
            if last is not None:
                g[last] += f
                f = []
            last = tokens[1]
            
        elif keyword == 'usemtl':
            material[name] = tokens[1]
            
        # v = vertex
        if keyword == 'v':
            x, y, z, *_ = [float(s) for s in tokens[1:]]
            v.append((x, y, z))
              
        # vt = texture
        if keyword == 'vt':
            i, j, *_ = [float(s) for s in tokens[1:]]
            vt.append((i, j))
        
        # f = face (polygon)
        if keyword == 'f':
            n = len(tokens) - 1
            polygon_types.add(n)

            trgl = [tuple(0 if not a else int(a) for a in s.split('/')[:2]) for s in tokens[1:]]
            for i in range(1, n-1):
                f.append((trgl[0], trgl[i], trgl[i+1]))
                nb_elements += 1
        
        # we do not manage:
        #  - comments (lines starting with #)
        #  - normals ('vn' keyword): normals are recomputed by SKUA
        #  - special effect on materials (lightning effects, etc)
        #  - texture JPG link (this is not fully automated. Need to import
        #    image as Voxet and run a macro to read an optional *.txt file)
        #  - line elements ('l' keyword)
        #  - or anything else... ('s' keyword for example)
        else:
            continue

    # fill g with the last group
    if last is not None:
        g[last] += f
        f = []
    else:
        g[name] = f
    
    job.end()
    
    if verbose:  
        if mtl_file is not None:
            log(f"Found a link to mtl file '{mtl_file}'")
        log("Done.")


######################
# Read material file #
######################
if mtl_file is not None:
    try:
        with open(f"{path}/{mtl_file}", 'r') as file:
            if verbose:
                log(f"Opening '{mtl_file}' file for reading...")
            
            current = None
            for line in file:
                tokens = line.split()
                
                if not tokens:
                    continue
            
                keyword = tokens[0]
                
                if keyword == 'newmtl':
                    current = tokens[1]
                    mtllib[current] = {'d': 1, 'Kd': '1 1 1'}
                
                # transparency
                elif keyword == 'd':
                    mtllib[current]['d'] = float(tokens[1])
                
                # color
                elif keyword == 'Kd':
                    mtllib[current]['Kd'] = ' '.join(tokens[1:])
                    set_colors = True
                
                # texture map for colors
                elif keyword == 'map_Kd':
                    mtllib[current]['map_Kd'] = tokens[1].replace('\\', '/')
                
                # texture map for opacity, used if no map_Kd
                elif keyword == 'map_D':
                    mtllib[current]['map_D'] = tokens[1].replace('\\', '/')
                
                # the following keywords are read and stored in the
                # material dictionary, but they will not be used
                elif keyword == 'Km':
                    mtllib[current]['Km'] = float(tokens[1])
                    
                elif keyword == 'Ks':
                    mtllib[current]['Ks'] = tokens[1]
                    
                elif keyword == 'Ka':
                    mtllib[current]['Ka'] = tokens[1]
                    
                elif keyword == 'Ni':
                    mtllib[current]['Ni'] = float(tokens[1])
                    
                elif keyword == 'Ns':
                    mtllib[current]['Ns'] = float(tokens[1])
                    
                else:
                    continue
                
            if verbose:
                log("Done.")

    except FileNotFoundError:
        log(f"***Error: could not find '{mtl_file}' file.")

        

###################
# Write *.ts file #
###################
for name, f in g.items():
    
    if not f:
        if verbose:
            log("Skipping empty session.")
        continue
    
    # we recreate our list of vertices where 1 PVRTX = 1 pair of (vertex, texture)
    nodes = {}
    for triangle in f:
        for vertice, texture in triangle:
            nodes[vertice] = nodes.get(vertice, set())
            nodes[vertice].add(texture)
    
    if verbose:
        log(f"Exporting {len(nodes)} nodes and {len(f)} triangles for '{name}'.")
    
    pvrtx_index = {}  # get vrtx index from (vertex, texture)
    pvrtx = [(ndv, ndv)]  # get (vertex, texture) indices from vrtx index
    i = 1
    for n in nodes:
        for t in nodes[n]:
            pvrtx_index[(n, t)] = i
            i += 1
            pvrtx.append((n, t))

    del nodes
    
    # we get the material, if there is one
    mtl = mtllib.get(material.get(name, None), None)

    ts_filename = f"{feature}_{name}".replace('.', '_') + ".ts"
    with open(f"{path}/{ts_filename}", 'w') as ts:
        
        def export(*args, **kwargs):
            "Convenience function simulating print(..., file=ts)"
            kwargs["file"] = ts
            print(*args, **kwargs)
        

        if verbose:
            log(f"Opening '{ts_filename}' file for writing...")
        
        if verbose:
            log("Exporting header...")
        export("GOCAD TSurf 1")
        export("HEADER {")
        export("name:", f"{feature}_{name}".replace('.', '_'))
        if mtl is not None:
            export("use_feature_color: false")
            Kd = mtl.get('Kd', '1 1 1')
            d = mtl.get('d', 1)
            export(f"*solid*color: {Kd} {d}")
            export(f"*solid*transparency: {d}")
        export("}")
        export("GOCAD_ORIGINAL_COORDINATE_SYSTEM")
        export("NAME Default")
        export("PROJECTION Unknown")
        export("DATUM Unknown")
        export("AXIS_NAME X Y Z")
        export("AXIS_UNIT m m m")
        export("ZPOSITIVE Elevation")
        export("END_ORIGINAL_COORDINATE_SYSTEM")
        export(f"GEOLOGICAL_FEATURE {feature}")
        export("GEOLOGICAL_TYPE lease")
        export("PROPERTIES U V")
        export("PROP_LEGAL_RANGES **none** **none** **none** **none**")
        export("NO_DATA_VALUES -99999 -99999")
        export("PROPERTY_CLASSES parametric_coordinate parametric_coordinate")
        export('PROPERTY_KINDS " Real Number" " Real Number"')
        export("PROPERTY_SUBCLASSES QUANTITY Float QUANTITY Float")
        export("ESIZES 1 1")
        export("UNITS unitless unitless")

        export("TFACE")
        if verbose:
            log("Exporting nodes...")
        job = JobTracer(len(pvrtx))
        for i in range(1, len(pvrtx)):
            job.progress()
            
            v_index, vt_index = pvrtx[i]
            X, Y, Z = v[v_index]
            U, V = vt[vt_index]
            # U, V might be > 1, we rescale between [0-1]
            export("PVRTX", i, X, Y, Z, U % 1, V % 1)
        job.end()
        
        if verbose:
            log("Exporting triangles...")
        job = JobTracer(len(f), top=False)
        for l, (t1, t2, t3) in enumerate(f):
            job.progress()
            export("TRGL", pvrtx_index[t1], pvrtx_index[t2], pvrtx_index[t3])
        job.end()
            
        export("END")
        
    if verbose:
        log("Done.")


##############################
# Export texture map listing #
##############################
texture_files = set()
with open(f"{path}/{feature}.txt", 'w') as file:
    # we export a simple list of TSurf / image files to be used as a texture
    # a SKUA macro is used to read this file, import everything and apply the texture
    if mtllib:
        if verbose:
            log(f"Exporting textured TSurfaces in {feature}.txt file...")
        for name, m in material.items():
            ts = f"{path}/{feature}_{name}".replace('.', '_') + ".ts"
            txt = mtllib[m].get('map_Kd', None) or mtllib[m].get('map_D', None)
            if txt is not None:
                # try to find the texture file (absolute path / in same folder / in subfolder)
                results = glob(txt) or glob(f"{path}/{txt}") or glob(f"{path}/**/{txt}", recursive=True)
                texture_file = results[0].replace('\\', '/') if results else txt
                print(ts, texture_file, file=file, sep='|')
                texture_files.add(texture_file)
                log(f"{ts} + {texture_file}")
            else:
                print(ts, file=file)
                log(ts)
        if verbose:
            log("Finished.")
    
    if verbose:
        log(f"Exporting non-textured TSurfaces in {feature}.txt file...")
    for name in g:
        if name not in material:
            # it has not yet been exported
            ts = f"{path}/{feature}_{name}".replace('.', '_') + ".ts"
            print(ts, file=file)
            log(ts)
    if verbose:
        log("Finished.")   


#########################
# print some statistics #
#########################

log('_' * LINE_SIZE)

s = 's' if len(g) > 1 else ''
log(f"Found {len(g)} object{s} or group{s} in '{obj_filename}' file:")
for name in g:
    log(f" - {feature}_{name}".replace('.', '_') + ".ts")

polys = [str(s) for s in sorted(list(polygon_types))]
npolygons = '-, '.join(polys[:-1]) + f'- and {polys[-1]}-polygons' if len(polys) > 1 else f'{polys[0]}-polygons'
log(f"\nElements encountered in '{obj_filename}' were {npolygons}.")

log(f"{len(v)} points were exported, and {nb_elements} triangles.\n")

if set_colors:
    log("Some surfaces have specific color. The option 'use feature color' must be")
    log("unchecked in SKUA-GOCAD on the surfaces after importing the *.ts files.\n")

if texture_files:
    log("Some surfaces have associated textures. The following image files")
    log("will be imported as 2D Voxet:")
    for txt in texture_files:
        log(f" - {txt}")


# free memory (those lists/dictionaries might grow quite large)
del v, vt, f, g, pvrtx, pvrtx_index

# close LOG_FILE if needed
if LOG:
    LOG_FILE.close()
