import sys
from pathlib import Path

try:
    ts_filename = sys.argv[1].replace('\\', '/')
except IndexError:
    print("Missing TS filename.")
    print(f"Usage: {sys.argv[0]} filename.ts [dx=XXX dy=YYY dz=ZZZ]")
    print("Aborting.")
    sys.exit()
    
a = Path(ts_filename)
if not a.exists():
    print(f"Cannot find file {ts_filename}.")
    print(f"Usage: {sys.argv[0]} filename.ts [dx=XXX dy=YYY dz=ZZZ]")
    print("Aborting.")
    sys.exit()

if len(sys.argv) not in [2, 5]:
    print(f"Usage: {sys.argv[0]} filename.ts [dx=XXX dy=YYY dz=ZZZ]")
    print("Aborting.")
    sys.exit()
   

def default():  
    """ Default values for translation of original Cedamavi project """ 
    return -259857.873, -7202081.152, -1080.884
    
    
try:
    argx = sys.argv[2]
    argy = sys.argv[3]
    argz = sys.argv[4]
except IndexError:
    dx, dy, dz = default()
else:
    if "dx=" in argx and "dy=" in argy and "dz=" in argz:
        try:
            dx = float(argx.split('dx=', 1)[1])
            dy = float(argy.split('dy=', 1)[1])
            dz = float(argz.split('dz=', 1)[1])
        except:
            print("Could not read (dx, dy, dz) values.")
            print(f"Usage: {sys.argv[0]} filename.ts [dx=XXX dy=YYY dz=ZZZ]")
            dx, dy, dz = default()
    else:
        print("Could not find dx, dy & dz parameters.")
        print(f"Usage: {sys.argv[0]} filename.ts [dx=XXX dy=YYY dz=ZZZ]")
        dx, dy, dz = default()
finally:
    print(f"Using (dx, dy, dz) = ({dx}, {dy}, {dz})")
        
output_file = f"translated_{ts_filename}"



with open(ts_filename, 'r') as f, open(output_file, 'w') as g:
    for line in f:
        if line.startswith('PVRTX'):
            tokens = line.split(' ')
            x, y, z = [float(s) for s in tokens[2:5]]
            newline = ' '.join(tokens[:2]) + f" {x+dx} {y+dy} {z+dz} " + ' '.join(tokens[5:])
            g.write(newline)
        else:
            g.write(line)
    
